const express=require('express')
const pg=require('pg')

const bodyParser=require('body-parser')

const port=process.env.PORT ||3000

const connectionString='postgres://cudptzoirbatka:23aec0b2b0e941d5a71926bde8bb14d26b216bd6e3ddfc891fac1162975e54c5@ec2-3-229-210-93.compute-1.amazonaws.com:5432/d26ph197quq31v'

var config = {
    host: 'uvgrid-test.cak8aytcldkp.us-east-2.rds.amazonaws.com',
    port: 5432,
    user: 'postgres',
    password: 'hailhydra',
    database: "UVGridDB",
    max: 10, 
    idleTimeoutMillis: 30000 
  }
const pool= new pg.Pool(config)

const app=express()
app.use(bodyParser.json())

app.listen(port,()=>{
    console.log('connected')
})

let myClient;

pool.connect((err,client,done)=>{

    //console.log(client)

    //Creating Standalone Event

    app.post('/create',(req,res)=>{
     // const obj=JSON.parse(req.body)
       console.log(req.body)
       res.send('done')
       const results= client.query('INSERT INTO standalone (speaker,category,topic,description,date,time,speakerid,privacy,image,regfee,tags) values($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11)',[req.body.speaker,req.body.category,req.body.topic,req.body.description,req.body.date,req.body.time,req.body.speakerid,req.body.privacy,req.body.image,req.body.regfee,req.body.tags],(err,results)=>{
           // res.send(results.rows)
          })

    })
    
   //Like request with JSON
    app.post('/like',(req,res)=>{
        const results= client.query('update standalone set likes =array_append(likes,$1) where speaker=$2;',[req.body.who,req.body.speaker],(err,results)=>{
            res.send('done')
           })

    })
   //Comment request with JSON
    app.post('/comment',(req,res)=>{
        client.query('update standalone set comments =array_append(comments,$1) where speaker=$2;',[req.body.comment,req.body.speaker],(err,results)=>{
            res.send('done')
           // console.log(req.body.comment)
           })

    })
    //Getting list
    app.get('/list',(req,res)=>{
        //ask query ?category=Tech
        if(req.query.category)
        {
            client.query('select * from standalone where category=$1',[req.query.category],(err,results)=>{
                res.send(results.rows)
               })
        }
        //ask query ?speaker=Utsav
    else if(req.query.speaker)
        {
            client.query('select * from standalone where speaker=$1',[req.query.speaker],(err,results)=>{
                res.send(results.rows)
               })
        }
        //No query then complete list
        else{
            client.query('select * from standalone',(err,results)=>{
                res.send(results.rows)
               })
        }

    })
   
})


